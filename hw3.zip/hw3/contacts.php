<html lang='ru'>
    <head>
        <title>Контакты</title>
        <meta name="description" content="Контакты для связи">
        <meta name="keywords" content="публикация, книги, печать, контакты, адрес, издательство книг">
        <meta name="viewport" content="width=976, maximum-scale=4, user-scalable=yes">
        <link rel="stylesheet" href="style1.css">
        <meta charset="utf-8">
    </head>
    <body>
<div class='header'>
        <div class='logo'>
</div>
</div>
<div class='selector'>
    <a href='index.php' name='index'>ГЛАВНАЯ</a>
    <a href='published.php' name='published'>НАШИ КНИГИ</a>
    <a href='rules.php' name='rules'>ПРАВИЛА ПРИЕМА КНИГ</a>
    <a href='prices.php' name='prices'>ЦЕНЫ</a>
    <a href='publishing.php' name='publishing'>ПУБЛИКАЦИЯ</a>
    <a href='admin.php' name='admin'>ВХОД</a>
</div>
<div class='background5'>
<div class='content'>
<h2>КОНТАКТЫ</h2>
                <h3>Департаменты</h3>
<p>прикладной литературы:</p>
<p>+7 (999) 999-9-000, добавочный 999</p>
<p>художественной литературы:</p>
<p>+7 (999) 999-9-000</p>
<p>детской литературы:</p>
<p>malysh@pechat.ru</p>
</div>
</div>
<div class='content2'>
<p>Наш офис</p>
<p>Адрес: г. Москва, Пресненская наб., д.7, стр.3, БЦ «Империя»</p>
<p>Адрес для корреспонденции: ООО «Издательство Печатник», 111111 г. Москва а/я №6.</p>
</div>
<div class='footer'>
</div>
</body>
</html>